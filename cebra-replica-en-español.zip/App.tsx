import React, { useState, useEffect, useRef, useCallback } from 'react';

// --- Icon Components ---
const MenuIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);

const ArrowRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
  </svg>
);

const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
    </svg>
);

const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
    </svg>
);


// --- Data ---
const navLinks = ["Servicios", "Soluciones", "Industrias", "Insights", "Acerca de", "Contacto"];

const heroCards = [
    { title: "Estrategia de Medios", description: "Creamos estrategias de medios personalizadas que conectan con tu audiencia y generan resultados." },
    { title: "Analítica y Datos", description: "Transformamos datos en decisiones inteligentes para optimizar tus campañas y maximizar el ROI." },
    { title: "Creatividad y Contenido", description: "Desarrollamos conceptos creativos y contenido atractivo que captura la esencia de tu marca." },
];

const services = [
    { title: "Publicidad Programática", image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" },
    { title: "Marketing en Buscadores (SEM)", image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" },
    { title: "Redes Sociales Pagadas", image: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80" },
    { title: "Marketing de Contenidos", image: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" },
];

const clientLogos = [
    "https://tailwindui.com/img/logos/158x48/transistor-logo-gray-900.svg",
    "https://tailwindui.com/img/logos/158x48/reform-logo-gray-900.svg",
    "https://tailwindui.com/img/logos/158x48/tuple-logo-gray-900.svg",
    "https://tailwindui.com/img/logos/158x48/savvycal-logo-gray-900.svg",
    "https://tailwindui.com/img/logos/158x48/statamic-logo-gray-900.svg",
    "https://tailwindui.com/img/logos/158x48/statickit-logo-gray-900.svg",
];

const insights = [
    { category: "Analítica", title: "El Futuro de la Medición: Más Allá de las Cookies", image: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" },
    { category: "Creatividad", title: "Tendencias Creativas que Dominarán el 2024", image: "https://images.unsplash.com/photo-1522125670776-3c7abb882bc2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" },
    { category: "Estrategia", title: "Cómo Construir una Estrategia de Medios Integrada", image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" },
];

// --- Components ---

const Header: React.FC = () => (
    <header className="bg-white py-4 px-4 sm:px-6 lg:px-8 border-b border-gray-200 sticky top-0 z-50 animate-fadeInUp">
        <div className="container mx-auto flex justify-between items-center">
            <div className="flex items-center space-x-2">
                 <span className="text-3xl font-extrabold text-brand-dark tracking-tighter">CEBRA</span>
            </div>
            <nav className="hidden lg:flex items-center space-x-8">
                {navLinks.map(link => <a key={link} href="#" className="text-gray-600 hover:text-brand-orange transition-colors duration-300">{link}</a>)}
            </nav>
            <button className="hidden lg:inline-block bg-brand-orange text-white font-bold py-2 px-6 rounded-full hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105">
                Hablemos
            </button>
            <button className="lg:hidden text-brand-dark">
                <MenuIcon className="h-6 w-6" />
            </button>
        </div>
    </header>
);

const Main: React.FC = () => (
    <main className="container mx-auto mt-16 px-4 sm:px-6 lg:px-8 text-center" style={{ animation: 'fadeInUp 1s ease-out' }}>
        <h1 className="text-5xl md:text-7xl font-extrabold text-brand-dark tracking-tighter leading-tight">
            Desbloquea el <span className="text-brand-orange">Crecimiento</span> de tu Negocio con CEBRA
        </h1>
        <p className="mt-4 text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            CEBRA: Creatividad Estratégica para Branding y Resultados de Alto Impacto.
        </p>
        <div className="mt-8 flex justify-center">
            <button className="bg-brand-dark text-white font-bold py-4 px-10 rounded-full hover:bg-gray-800 transition-all duration-300 transform hover:scale-105 text-lg">
                Descubre cómo
            </button>
        </div>
    </main>
);

const HeroCards: React.FC = () => (
    <section className="container mx-auto mt-20 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {heroCards.map(card => (
                <div key={card.title} className="bg-white p-8 rounded-2xl border border-gray-200 hover:shadow-2xl hover:-translate-y-2 transition-all duration-300" style={{ animation: 'fadeInUp 1s ease-out 0.5s forwards', opacity: 0 }}>
                    <h3 className="text-2xl font-bold text-brand-dark">{card.title}</h3>
                    <p className="mt-4 text-gray-600">{card.description}</p>
                    <a href="#" className="mt-6 inline-flex items-center text-brand-orange font-bold group">
                        Ver más <ArrowRightIcon className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                    </a>
                </div>
            ))}
        </div>
    </section>
);

const Services: React.FC = () => (
    <section className="bg-gray-50 py-20 mt-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
                <h2 className="text-4xl md:text-5xl font-extrabold text-brand-dark tracking-tighter">Nuestros Servicios</h2>
                <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Potenciamos marcas a través de soluciones digitales innovadoras y basadas en datos.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {services.map(service => (
                    <div key={service.title} className="group relative rounded-2xl overflow-hidden cursor-pointer">
                        <img src={service.image} alt={service.title} className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-500" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
                        <div className="absolute bottom-0 left-0 p-6">
                            <h3 className="text-white text-2xl font-bold">{service.title}</h3>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </section>
);

const Clients: React.FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const logosContainerRef = useRef<HTMLDivElement>(null);

    const duplicatedLogos = [...clientLogos, ...clientLogos];

    const resetTimeout = useCallback(() => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
    }, []);

    useEffect(() => {
        resetTimeout();
        timeoutRef.current = setTimeout(
            () =>
                setCurrentIndex((prevIndex) =>
                    prevIndex === clientLogos.length ? 0 : prevIndex + 1
                ),
            3000
        );

        return () => {
            resetTimeout();
        };
    }, [currentIndex, resetTimeout]);

    const handleTransitionEnd = () => {
        if (currentIndex === clientLogos.length) {
            if (logosContainerRef.current) {
                logosContainerRef.current.style.transition = 'none';
                setCurrentIndex(0);
                setTimeout(() => {
                    if (logosContainerRef.current) {
                        logosContainerRef.current.style.transition = 'transform 0.5s ease-in-out';
                    }
                }, 50);
            }
        }
    };

    const handleManualNav = (direction: 'prev' | 'next') => {
        resetTimeout();
        if (direction === 'next') {
            setCurrentIndex(prev => prev === clientLogos.length ? 0 : prev + 1);
        } else {
             if (currentIndex === 0) {
                if (logosContainerRef.current) {
                    logosContainerRef.current.style.transition = 'none';
                    setCurrentIndex(clientLogos.length);
                    setTimeout(() => {
                         if (logosContainerRef.current) {
                           logosContainerRef.current.style.transition = 'transform 0.5s ease-in-out';
                           setCurrentIndex(clientLogos.length - 1);
                         }
                    }, 50);
                }
            } else {
                setCurrentIndex(prev => prev - 1);
            }
        }
    };


    return (
        <section className="py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-4xl md:text-5xl font-extrabold text-brand-dark tracking-tighter">Nuestros Clientes</h2>
                <div className="relative mt-12 overflow-hidden group">
                    <div
                        ref={logosContainerRef}
                        className="flex"
                        style={{
                            transform: `translateX(-${currentIndex * (100 / clientLogos.length)}%)`,
                            width: `${clientLogos.length * 200}%`,
                            transition: 'transform 0.5s ease-in-out',
                        }}
                        onTransitionEnd={handleTransitionEnd}
                    >
                        {duplicatedLogos.map((logo, index) => (
                            <div key={index} className="flex-shrink-0" style={{ width: `${100 / (clientLogos.length * 2)}%` }}>
                                <div className="flex justify-center items-center h-24">
                                    <img src={logo} alt={`Cliente ${index + 1}`} className="max-h-12 w-auto object-contain" />
                                </div>
                            </div>
                        ))}
                    </div>
                     <button onClick={() => handleManualNav('prev')} className="absolute left-0 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-2 text-gray-700 shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white focus:outline-none">
                        <ChevronLeftIcon className="h-6 w-6" />
                    </button>
                    <button onClick={() => handleManualNav('next')} className="absolute right-0 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-2 text-gray-700 shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white focus:outline-none">
                        <ChevronRightIcon className="h-6 w-6" />
                    </button>
                </div>
            </div>
        </section>
    );
};


const Insights: React.FC = () => (
    <section className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
                <h2 className="text-4xl md:text-5xl font-extrabold text-brand-dark tracking-tighter">Insights de la Industria</h2>
                 <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Mantente a la vanguardia con nuestros análisis y perspectivas sobre el futuro del marketing digital.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {insights.map(insight => (
                    <div key={insight.title} className="group cursor-pointer">
                        <div className="overflow-hidden rounded-2xl">
                             <img src={insight.image} alt={insight.title} className="w-full h-64 object-cover transform group-hover:scale-110 transition-transform duration-500" />
                        </div>
                        <div className="p-4">
                            <p className="text-brand-orange font-bold text-sm">{insight.category}</p>
                            <h3 className="mt-2 text-xl font-bold text-brand-dark group-hover:text-brand-orange transition-colors duration-300">{insight.title}</h3>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </section>
);


const Footer: React.FC = () => (
    <footer className="bg-brand-dark text-white">
        <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 className="text-xl font-extrabold tracking-tighter">CEBRA</h3>
                    <p className="mt-4 text-gray-400">Desbloqueando el crecimiento del negocio.</p>
                </div>
                 <div>
                    <h4 className="font-bold text-gray-200">Navegación</h4>
                    <ul className="mt-4 space-y-2">
                        {navLinks.slice(0, 4).map(link => <li key={link}><a href="#" className="text-gray-400 hover:text-white transition-colors">{link}</a></li>)}
                    </ul>
                </div>
                <div>
                     <h4 className="font-bold text-gray-200">Legal</h4>
                    <ul className="mt-4 space-y-2">
                        <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Política de Privacidad</a></li>
                        <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Términos de Servicio</a></li>
                    </ul>
                </div>
                 <div>
                    <h4 className="font-bold text-gray-200">Conecta</h4>
                     <p className="mt-4 text-gray-400">Únete a nuestra newsletter para recibir los últimos insights.</p>
                      <form className="mt-4 flex">
                        <input type="email" placeholder="Tu email" className="w-full px-4 py-2 rounded-l-md text-gray-800 focus:outline-none" />
                        <button className="bg-brand-orange text-white font-bold px-4 py-2 rounded-r-md hover:bg-opacity-90 transition-colors">&rarr;</button>
                    </form>
                </div>
            </div>
            <div className="mt-8 border-t border-gray-800 pt-8 text-center text-gray-500">
                <p>&copy; {new Date().getFullYear()} CEBRA. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
);


const App: React.FC = () => {
  return (
    <div className="bg-white font-sans">
      <Header />
      <Main />
      <HeroCards />
      <Services />
      <Clients />
      <Insights />
      <Footer />
    </div>
  );
};

export default App;
